<?php 
	//dat duong dan cho bien $fileLayout de load template vao day
	$this->fileLayout = "Views/Backend/Layout1.php";
 ?>
<h1 style="text-align: center;">Phạm Đức Văn</h1>
